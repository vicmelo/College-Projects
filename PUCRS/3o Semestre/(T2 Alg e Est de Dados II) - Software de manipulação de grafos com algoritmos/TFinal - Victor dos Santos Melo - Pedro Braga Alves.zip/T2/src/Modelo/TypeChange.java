/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 *
 * @author victor
 */
public enum TypeChange {
    AddEdge,RemoveEdge,AddNode,RemoveNode,AlgorithmStep;
}
